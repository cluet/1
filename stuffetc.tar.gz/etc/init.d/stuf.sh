#!/bin/sh

START=60

/etc/init.d/bmminer.sh stop &&

sleep 1 && 

/usr/ssbin/bmminer.sh restart &&

sync