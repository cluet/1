#!/usr/bin/env bash


#0/1
if [ "$1" != "local" ]; then
    local_install=0
else
    local_install=1
fi


[[ -e /hive/bin/colors ]] && source /hive/bin/colors


cd `dirname $0`

which sshpass > /dev/null || (echo -e "${RED}sshpass${NOCOLOR} is required, try apt-get install sshpass" && exit 1)
which jq > /dev/null || (echo -e "${RED}sshpass${NOCOLOR} is required, try apt-get install jq" && exit 1)

IPS=`cat ips.txt | grep -v '#' | grep -v '^$'`
[[ -z $IPS ]] && echo -e "${YELLOW}No IPs in the list${NOCOLOR}" && exit 1

. config.txt

#[[ -z $FARM_HASH ]] && echo -e "${RED}FARM_HASH is empty, set it in config${NOCOLOR}" && exit 1
echo -e "IPs count `echo "$IPS" | wc -l`"


if [[ $local_install == 1 ]]; then
	[ ! -e "T17_H_uramdisk.image.gz" ] && wget http://download.hiveos.farm/asic/repo/t17-s17/T17_H_uramdisk.image.gz
	[ ! -e "S17_H_OM_uramdisk.image.gz" ] && wget http://download.hiveos.farm/asic/repo/t17-s17/S17_H_OM_uramdisk.image.gz
	[ ! -e "S17PRO_H_OM_uramdisk.image.gz" ] && wget http://download.hiveos.farm/asic/repo/t17-s17/S17PRO_H_OM_uramdisk.image.gz
	[ ! -e "T15_20190507_HIVE_uramdisk.image.gz" ] && wget http://download.hiveos.farm/asic/repo/t17-s17/T15_20190507_HIVE_uramdisk.image.gz
fi


for ip in $IPS; do
	ASIC_MODEL=`echo '{"command":"stats"}' | nc $ip 4028 | tr -d '\0\n' | sed 's/}{/\},{/' | jq -r .STATS[0].Type`
	echo -e "\033[0;32m$ip $ASIC_MODEL\e[0m"
	if [[ -z $ASIC_MODEL ]]; then
		echo -e "\033[1;31mModel not found or miner not running. If the miner recently rebooted, wait 10 minutes.\033[0m"
		continue
	fi
	case $ASIC_MODEL in
		"Antminer T17")
			fw_name="T17_H_uramdisk.image.gz"
		;;
		"Antminer T15")
			fw_name="T15_20190507_HIVE_uramdisk.image.gz"
		;;
		"Antminer S17")
			fw_name="S17_H_OM_uramdisk.image.gz"
		;;
		"Antminer S17 Pro")
			fw_name="S17PRO_H_OM_uramdisk.image.gz"
		;;
	esac
	ssh-keygen -f "/root/.ssh/known_hosts" -R "$ip"
	install_cmd0="rm -rf /mnt/ramdisk/* && mkdir -p /mnt/ramdisk && mount -t tmpfs -o size=100m tmpfs /mnt/ramdisk"
	install_cmd1="rm -rf /mnt/ramdisk/* && mkdir -p /mnt/ramdisk && mount -t tmpfs -o size=100m tmpfs /mnt/ramdisk && cd /mnt/ramdisk && wget http://download.hiveos.farm/asic/repo/t17-s17/$fw_name"
	install_cmd2="cd /mnt/ramdisk && [ -e $fw_name ] && /usr/sbin/flash_erase /dev/mtd1 0x0 0x100 && /usr/sbin/nandwrite -p -s 0x0 /dev/mtd1 $fw_name && sleep 1 && /sbin/reboot"
	#3=1+2
	install_cmd3="mkdir -p /mnt/ramdisk && mount -t tmpfs -o size=100m tmpfs /mnt/ramdisk && cd /mnt/ramdisk && wget http://download.hiveos.farm/asic/repo/t17-s17/$fw_name && [ -e $fw_name ] && /usr/sbin/flash_erase /dev/mtd1 0x0 0x100 && /usr/sbin/nandwrite -p -s 0x0 /dev/mtd1 $fw_name && sleep 1 && /sbin/reboot"
	echo -e "> Processing $LOGIN@${CYAN}$ip${NOCOLOR}"
	if [[ -e "/usr/bin/compile_time" ]]; then
		echo "Use Ubuntu/Debian"
#		sshpass -p$PASS ssh $LOGIN@$ip -p 22 -oConnectTimeout=25 -oStrictHostKeyChecking=no "$install_cmd"
#		sshpass -p$PASS scp -P 22 -oConnectTimeout=15 -oStrictHostKeyChecking=no S17_HIVE_2-OM_uramdisk.image.gz $LOGIN@$ip:/mnt/ramdisk &
	else
		if [[ $local_install == 1 ]]; then #download fw
			sshpass -p$PASS ssh $LOGIN@$ip -p 22 -oConnectTimeout=25 -oStrictHostKeyChecking=no "$install_cmd0"
			sshpass -p$PASS scp -P 22 -oConnectTimeout=15 -oStrictHostKeyChecking=no $fw_name $LOGIN@$ip:/mnt/ramdisk
			sshpass -p$PASS ssh $LOGIN@$ip -p 22 -oConnectTimeout=25 -oStrictHostKeyChecking=no "$install_cmd2" &
		else
			sshpass -p$PASS ssh $LOGIN@$ip -p 22 -oConnectTimeout=25 -oStrictHostKeyChecking=no "$install_cmd3" &
		fi
	fi


	if [[ $? -ne 0 ]]; then
		echo -e "${YELLOW}Error connecting${NOCOLOR}"
	else
		echo -e "${GREEN}OK${NOCOLOR}"

		#Comment it in file
		sed -i "s/^$ip$/\#$ip/g" ips.txt
	fi

done
