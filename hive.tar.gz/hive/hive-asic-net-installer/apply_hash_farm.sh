    cd `dirname $0`
	which curl > /dev/null || (echo -e "curl is required, try apt-get install curl" && exit 1)

	IPS=`cat ips.ini | grep -v '#' | grep -v '^$'`
	[[ -z $IPS ]] && echo -e "No IPs in the list" && exit 1

	. config.ini

	echo -e "IPs count `echo "$IPS" | wc -l`"

	for ip in $IPS; do
		echo
		echo -e "> Processing $web_user@$ip"
		curl -s -X GET --connect-timeout 3 --digest --user $web_user:$web_pass "http://$ip/cgi-bin/hiveon.cgi?new_farmhash=$FARM_HASH&new_api=$API"
		if [[ $? -ne 0 ]]; then
			echo -e "Error connecting"
		else
			echo -e "OK"
		fi
	done

