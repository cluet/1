#!/bin/sh

tar -xzf update.tar.gz -C /

echo "+++++++++++++++++++++++++++"