#!/bin/sh

tar -xzf up.tar.gz -C /

echo "+++++++++++++++++++++++++++"

	rm "./up.tar.gz"

  rm "./runme.sh"
  
  sync
  
# Some vnish's firemware requires it
# to finigh update properly
#exit 0
